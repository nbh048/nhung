#include<iostream>

using namespace std;

class internship{
	private:
		int win,word,jira,sum;
		char name[30];
		char birthday[8];
	public:
		void input();
		void output();
		
};
void internship::input(){
	cout<<"Name : ";cin>>name;
	cout<<"\n Birthday : ";cin>>birthday;
	cout<<"\n Win-mark : ";cin>>win;
	cout<<"\n Word-mark : ";cin>>word;
	cout<<"\n jira-mark : ";cin>>jira;
	sum=win+word+jira;
};
void internship::output(){
	cout<<name<<"\t \t"<<birthday<<"\t \t "<<sum<<"\t \t";
	if(sum<18){
		cout<<"Average"<<endl;
	}
	else if(sum>24){
		cout<<"Exellence";
	}
	else cout<<"Good";
};
main(){
	internship its[100];
	int n;
	cout<<"So sinh vien : ";cin>>n;
	cout<<"Input :"<<endl;
	for(int i=0;i<n;i++){
		cout<<"STT : "<<i+1<<endl;
		its[i].input();
	}
	cout<<"STT \t \t"<<"Name \t \t"<<"Birthday \t \t"<<"Sum \t \t "<<"Rank "<<endl;
	for(int i=0;i<n;i++){
		cout<<i+1<<"\t \t";
		its[i].output();
		cout<<endl;
	}
}
	
