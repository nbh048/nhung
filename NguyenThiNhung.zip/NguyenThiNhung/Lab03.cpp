#include<iostream>

using namespace std;

struct Class{
	string classname;
	string year;
};

struct Student{
	int id;
	string name;
	string age;
	Class lop;
}students[20];

struct Subject{
	int testMark1;
	int testMark2;
	int examMark1;
	int examMark2;
	int sum;
}Math[20], Physics[20], Chemistry[20];

void displayMenu(){
	cout<<"\n Menu "<<endl;
	cout<<"1. Input student infor"<<endl;
	cout<<"2. Input mark of student "<<endl;
	cout<<"3. output results of 1 student"<<endl;
	cout<<"4. Output results of 1 class"<<endl;
	cout<<"5. Break"<<endl;
}

void inputStudentInfo(int n){
	for(int i=0;i<n;i++){
		cout<<"Student "<<i+1<<":"<<endl;
		students[i].id=i+1;
		cout<<"Name: ";cin>>students[i].name;
		cout<<"Age: ";cin>>students[i].age;
		cout<<"Class Name: ";cin>>students[i].lop.classname;
		cout<<"Year: ";cin>>students[i].lop.year;
		cout<<endl;
	}
}
void inputMark(int n){
	for(int i=0;i<n;i++){
		cout<<"Mark Of Student "<<i+1<<":"<<endl;
		cout<<"Math:";
		cout<<"testMark1 :";cin>>Math[i].testMark1;
		cout<<"testMark2: ";cin>>Math[i].testMark2;
		cout<<"examMark1 : ";cin>>Math[i].examMark1;
		cout<<"examMark2 : ";cin>>Math[i].examMark2;
		Math[i].sum=Math[i].testMark1+Math[i].testMark2+Math[i].examMark1+Math[i].examMark2;
		cout<<"Physics:";
		cout<<"testMark1 :";cin>>Physics[i].testMark1;
		cout<<"testMark2 : ";cin>>Physics[i].testMark2;
		cout<<"examMark1 : ";cin>>Physics[i].examMark1;
		cout<<"examMark2 : ";cin>>Physics[i].examMark2;
		Physics[i].sum=Physics[i].testMark1+Physics[i].testMark2+Physics[i].examMark1+Physics[i].examMark2;
		cout<<"Chemistry:";
		cout<<"testMark1 : ";cin>>Chemistry[i].testMark1;
		cout<<"testMark2 : ";cin>>Chemistry[i].testMark2;
		cout<<"examMark1 :";cin>>Chemistry[i].examMark1;
		cout<<"examMark2 : ";cin>>Chemistry[i].examMark2;
	    Chemistry[i].sum=Chemistry[i].testMark1+Chemistry[i].testMark2+Chemistry[i].examMark1+Chemistry[i].examMark2;
	}
}

void outputStudent(){
	cout<<"Input STT :";
	int id;
	cin>>id;
	for(int i=0;i<20;i++){
		if(students[i].id==id){
			cout<<"Mark Of Student "<<i+1<<":"<<endl;
			cout<<"Math : "<<Math[i].sum<<endl;
			cout<<"Physics : "<<Physics[i].sum<<endl;
			cout<<"Chemistry : "<<Chemistry[i].sum<<endl;
		}
	}
}

void outputClass(){
	cout<<"Input Class Name:";
	string name,year;
	cin>>name;
	cout<<"Input Class Year:";
	cin>>year;
	Class cl;
	cl.classname=name;
	cl.year=year;
	cout<<"Result Of class:  "<<cl.classname<< " year :"<<cl.year<<endl;
	for(int i=0;i<20;i++){
		if(students[i].lop.classname==cl.classname&&students[i].lop.year==cl.year){
			cout<<students[i].name<<endl;
			cout<<"Math : "<<Math[i].sum<<endl;
			cout<<"Physics : "<<Physics[i].sum<<endl;
			cout<<"Chemistry : "<<Chemistry[i].sum<<endl;
		}
	}
}

main(){
	int choice;
	displayMenu();
	cin>>choice;
	while(1){
		if(choice==5){
			break;
		}
		else{
            switch(choice){
            	int n;
        	    case 1: 
					cout<<"Nhap so sinh vien : ";cin>>n;
					inputStudentInfo(n);
					break;
        	    case 2: inputMark(n);break;
        	    case 3:outputStudent();break;
        	    case 4: outputClass();break;
		    }
		}	
        displayMenu();cin>>choice;
	}
}


