#include<iostream>
#include<string>
#include<fstream>
 
using namespace std;
 
main(){
	float sum = 0;

	fstream f;
	f.open("input.txt", ios::in);
 
	float data[100]; 
	int i=0;
	
	while(!f.eof()){
		f>>data[i];
		i++;
	}

	f.close();
 	
 	cout<<"Gia tri trong file: "<<endl;
	for(int j=0;j<i;j++){
		cout<<data[j]<<" ";
		sum = sum + data[j]*data[j];
	}
	cout<<endl;
	cout<<"Tong cac phan tu trong input.txt la : "<<sum<<endl;
}
