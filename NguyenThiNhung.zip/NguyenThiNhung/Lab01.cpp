#include<iostream>
using namespace std;
main(){
	int a[10],t;
	//Input
	for(int i=0;i<10;i++){
		cout<<"a["<<i+1<<"]= ";
		cin>>a[i];
	}
	//Find the maximum number
	int max=a[0];
	for(int i=0;i<10;i++){
		if(a[i]>max){
			max=a[i];
		}
	}
	cout<<"Max : "<<max;
	
	//Find the minimum number
	
	int min=a[0];
	for(int i=0;i<10;i++){
		if(a[i]<min){
			min=a[i];
		}
	}
	cout<<"\n Min : "<<min;
	//Find the number has largest frequent existence
	int B[10];
	for(int i=0;i<10;i++){
		B[i]=1;
	}
	for(int i=0;i<9;i++){
		for(int j=i+1;j<10;j++){
			if(a[i]==a[j]){
				B[i]++;
				B[j]=-1;
			}
		}
	}
	int maxCount = 0;
	int index;
	for(int i=0;i<10;i++){
		if(B[i]>maxCount&&B[i]!=-1){
			maxCount = B[i];
			index = i;
		}
	}
	cout<<"\nMost Freq:  : "<<a[index]<<endl;
	//Sort
	for(int i=0;i<10;i++){
		for(int j=i+1;j<10;j++){
			if(a[i]>a[j]){
				int t=a[i];
				a[i]=a[j];
				a[j]=t;
			}
		}
	}

	cout<<"\n Day da sap xep la :  ";
	for(int i=0;i<10;i++){
		cout<<a[i]<<" ";
	}
}
